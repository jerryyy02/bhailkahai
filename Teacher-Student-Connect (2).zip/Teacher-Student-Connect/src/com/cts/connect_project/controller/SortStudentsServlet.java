package com.cts.connect_project.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cts.connect_project.bean.Register;
import com.cts.connect_project.service.ResourceService;
import com.cts.connect_project.service.ResourceServiceImpl;

/**
 * Servlet implementation class SortStudentsServlet
 */
@WebServlet("/SortStudentsServlet")
public class SortStudentsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SortStudentsServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String query="";	
		String order=request.getParameter("order");
		System.out.println(order);
		System.out.println("in sort");
		//sort by author
		if(order.equals("NameAZ"))
		
		{
		query = "Select * from user where cat='student' order by fname asc";
		}
		else if(order.equals("NameZA"))
		{
		query = "Select * from user where cat='student' order by fname desc";
		}
		
		//sort by year
		else if(order.equals("SpecializationAZ"))
		{
		query = "Select * from user where cat='student' order by specialization";
		}
		else if(order.equals("SpecializationZA"))
		{
		query = "Select * from user where cat='student' order by specialization desc";
		}
		
		//sort by title
		
		/*
		else
		{
		query = "Select * from resources order by subject desc";
		}
		*/
		
		
		
		ResourceService resourceService = new ResourceServiceImpl();
		List<Register> register = new ArrayList<Register>();
		RequestDispatcher requestDispatcher = null;
		HttpSession session = request.getSession(true);
		
		register.addAll(resourceService.filterStudent(query));
		session.setAttribute("students", register);
		request.setAttribute("students", register);
		
		
		requestDispatcher = request.getRequestDispatcher("students.jsp");
		requestDispatcher.forward(request, response);
	}

}
