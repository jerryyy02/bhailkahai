package com.cts.connect_project.bean;

import java.io.InputStream;

public class Resource {
	
	private String subject;
	private String title;
	private String author;
	private String year;
	private InputStream image;
	private InputStream file;

	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public String getYear() {
		return year;
	}
	public void setYear(String year) {
		this.year = year;
	}
	public Resource() {
		super();
	}

	
	
	
	public Resource(String subject, String title, String author, String year) {
		super();
		this.subject = subject;
		this.title = title;
		this.author = author;
		this.year = year;
	}
	public Resource(String subject, String title, String author, String year, InputStream image, InputStream file) {
		super();
		this.subject = subject;
		this.title = title;
		this.author = author;
		this.year = year;
		this.image = image;
		this.file = file;
	}
	@Override
	public String toString() {
		return "Resource [subject=" + subject + ", title=" + title + ", author=" + author + ", year=" + year + "]";
	}
	public InputStream getImage() {
		return image;
	}
	public void setImage(InputStream image) {
		this.image = image;
	}
	public InputStream getFile() {
		return file;
	}
	public void setFile(InputStream file) {
		this.file = file;
	}

	
	
}